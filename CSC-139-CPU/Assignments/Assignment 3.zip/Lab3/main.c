#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

int pNum[20], arivalT[20], burstT[20];
int countP=0, countA=0, countB=0;

#define FALSE (1==0)
#define TRUE  (1==1)


void schedule(int pid[], int run[], int arrival[]);

void fcfs( );				
void srtf();
void rr(int);


int main(int argc, char *argv[]){
	
	if(argc >=2 && argc <3) {
		
      fprintf(stderr, "USAGE: a.out input.1 fcfs \n");
	  fprintf(stderr, "USAGE: a.out input.1 srtf \n");
	  fprintf(stderr, "USAGE: a.out input.1 rr [quatum]     <-- for rr\n");
		   return -1;
   }
   
   int u;

    char fname[] = "input.1";
    char buf[256];
    char *p;

    FILE * f = fopen(fname, "r");
   
    while(p = fgets(buf, sizeof(buf), f)) {
        int x, i = 0, n = 0;

        while (sscanf(p+=n, "%d%n", &x, &n) > 0){

            if (i >= 0)
				i++;
			
			 if (i == 1)
			 {
				pNum[countP]=x;
				countP++;
				
			}
			
			if (i == 2){
				arivalT[countA]=x;
				countA++;
				
			}
			
			if (i == 3)
			{
				burstT[countB]=x;
				countB++;
				
			}

		}
     
    }
	
	printf("Total %d are read from %s.",countP,argv[1]);

	if (strcmp(argv[2],"fcfs")==0){ 
	        	

	if(countP == 0)	goto empty_queue;	
	fcfs();				

	return 0;			

	empty_queue:	
	printf("\nProcess queue is empty. End of run.\n");
	
	}
	
	if (strcmp(argv[2],"srtf")==0)
		srtf();

	if (strcmp(argv[2],"rr")==0)
	        	
		rr(atoi(argv[3]));
}

void fcfs()
{
	int size=countP;
	int i, j, result;
	float waitingTimeAvg=0,  turnAroundTimeavg=0.0f;
	int arrival[size], burst[size], waiting[size];
    int turn_around_time[size];

	
	for(i=0; i<size; ++i)	
		waiting[i]=0;	

	for(i=0; i<size; i++)
	{
		arrival[i]=arivalT[i];
		burst[i]=burstT[i];
	}


	for(i=1; i<size; ++i) {
		result=0;
		for(j=0; j<i; ++j)	result+= burst[j];
		waiting[i]=result - arrival[i];

	}

	printf("\nWaiting Time:\t\n");
	for(i=0; i<size; i++){
		result+=waiting[i];

	}

	for(i=0; i<size; ++i)	
		waitingTimeAvg=waitingTimeAvg+(double)waiting[i];
	
	waitingTimeAvg/=(double)size;
	
	for(i=0; i<size; ++i)
	{	
		turn_around_time[i]= burst[i] + waiting[i];
		turnAroundTimeavg+=turn_around_time[i];
	}
	
	printf("===================================================================");
	
	int k, count=0,z=0,l=0;
	char run[15] = "running";
	char fin[15] ="finshed..";

				
	printf("\n");

	for(k=0; k<countP; k++){	
		for(i=0; i<=burst[k]; i++){

			printf("<system time %d > process\t %d is %s\n", count,pNum[z], run );
			
			if(l){
		
				count--;
				l=0;
			}
			
			if(burst[k]==i+1)
			{
				memcpy(run,fin, sizeof(fin)); 
					l=1;
			}
			count++;
		}
		memcpy(run,"running", sizeof(fin)); 
		z++;
	}

	printf("<system time %d All processes finish...........................\n",count );
	printf("=================================================================");
	
	printf("\ncpu usage:\t 100%c",'%' );
	printf("\nAverage Waiting Time:\t%.2f", waitingTimeAvg);
	printf("\nAverage response Time:\t%.2f", waitingTimeAvg);
	printf("\nAverage Turn Around Time:%.2f \t",turnAroundTimeavg/countP);	
	
	printf("\n");
}


void srtf(){
	 int n,burst[countP],oldtime[countP],bursttimetozero[countP], arrival[countP],tat[countP],wt[countP],rt[countP],finish[countP],twt=0,ttat=0,total=0; 
	 
		
	 int true=1;
	 n=countP;
	 int response_time =0;
	 float average_response_time=0;
	 int i;
	 char run[15] = "running";
	 char fin[15] ="finshed..";

	for(i=0; i<n; i++){
		arrival[i]=arivalT[i];
		burst[i]=burstT[i];
		
		rt[i]=burst[i]; 
	    finish[i]=0;        
	    wt[i]=0;
        tat[i]=0;         
		total+=burst[i];  
		oldtime[i]=0;
		bursttimetozero[i]=burstT[i];
	}
	
	
	printf("this is total:%d\n", total);
	
	int time,next=0,old;
  
	for(time=0;time<total;time++)    
	{
        old=next;    

int low;   

int bursts=0, j=0;   
 for(i=0;i<n;i++)

            if(finish[i]==0){low=i; break; }

        for(i=0;i<n;i++)

            if(finish[i]!=1)

                if(rt[i]<rt[low] && arrival[i]<=time){

                        low=i;   
					
					
					oldtime[next]=time;
				
				}

				next=low;

	
	if(old!=next&&time!=0)
	
	if(finish[old]==1)
		memcpy(run,"finish...", sizeof(fin)); 
		

	else
		memcpy(run,"running", sizeof(fin)); 

        rt[next]=rt[next]-1;         
		if(rt[next]==0) finish[next]=1;
		
        for(i=0;i<n;i++){
			
            if(i!=next && finish[i]==0 && arrival[i]<=time)

                wt[i]++;

		}	
				if(run[0]=='f')
				{
					printf("<System time: (%d)> Process %d is %s\n",time, old+1,run);
					printf("<System time: (%d)> Process %d is %s\n",time, next+1,"running");
	
				}

				else
					printf("<System time: (%d)> Process %d is %s\n",time, next+1, run);
					
					
				}
				
			printf("<System time: (%d)> All Processes finish.......\n",time);

    for(i=0;i<n;i++){  
	
			if(!finish[i]) {
					printf("Scheduling failed, cannot continue\n");

				return;
	}}

      for( i=0;i<n;i++)
    {   twt+=wt[i];         
		tat[i]=wt[i]+burst[i];         
		ttat+=tat[i];
      }

      printf("\ncpu usage: 100%c\n",'%' );
	  printf("Avg Waiting time  =%0.2f\navgTurnaround time =%0.2f\n",(float)twt/countP,(float)ttat/countP);

}
struct process
{
    int no;
    int at,et,wt,tt;
    int tet;
    int t;
};
void rr(int timeq){
	 
	struct process p[countP];
    int i,j,k;
    int np=countP;
   
 
    for (i=0;i<np;i++)
    {
		p[i].et=burstT[i];
        p[i].tet+=p[i].et;
        p[i].at=arivalT[i];
        p[i].no=i+1;
		  p[i].t=0;
    }
	
	
    int q = timeq;
 
    int totaltime=0;
    
    for(i=0;i<np;i++)
    {
        totaltime+=p[i].et;
    }
 
    i=0;
    k=0;
 
    int rrg[99];
    for(j=0;j<totaltime;j++)
    {
        if((k==0)&&(p[i].et!=0))
        {
            p[i].wt=j;
            if((p[i].t!=0))
            {
                p[i].wt-=q*p[i].t;

            }
        }
        if((p[i].et!=0)&&(k!=q))
        {
            rrg[j]=p[i].no;
            p[i].et-=1;
            k++;
        }
        else
        {
            if((k==q)&&(p[i].et!=0))
                p[i].t+=1;
        
            i=i+1;
            if(i==np)
                i=0;
 
            k=0;
            j=j-1;
        }
    }
	
	
	int twt=0;
    int ttt=0;
 
			
    for(i=0;i<np;i++)
    {
        p[i].tt=p[i].wt+p[i].tet;
        ttt+=p[i].tt;
        twt+=p[i].wt;

    }

    printf("\n Average Waiting Time:%0.2f",(float)twt/np);
	printf("\n Average Turn Around Time:%0.2f\n",(float)ttt/np);

	
}




	

	
	