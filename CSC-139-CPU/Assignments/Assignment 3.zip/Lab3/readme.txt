Extract the files main.c and input.1 in the SAME folder in athena. 

In athena: Please use cd to change your directories to the same directories where your placed the extracted main.c files in athena. 

In order to compile the code, type gcc main.c.

To run the code type

a.out input.1 rr 4
or 
a.out input.1 srtf 
or 
a.out input.1 fcfs






