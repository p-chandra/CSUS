-Compile
	gcc proj2.c
-Execute
	./a.out input.1 FCFS
	./a.out input.1 SRTF
	./a.out input.1 RR 2

*Case sensitive
