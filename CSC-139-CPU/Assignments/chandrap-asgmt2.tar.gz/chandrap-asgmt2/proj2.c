#include<stdio.h>
#include<string.h>
#include<stdlib.h>	
#include<time.h>

int main(int argc, char  *argv[])
{
   int pid[20],arivalTime[20],burstTime[20],cTime[20],waitTime[10],tArivalTime[20];
   int i,j,k,count,temp,temp1;
   int n,q,r=0,st=0,c=0,counter=0,number,pno=0,tot =0, m = 0, max =0, min =0;
   float temp2=0,awt=0,temp3=0;

    typedef struct{
   	    int pid2,arivalT,burstT2,burstT1,ct2,turnAround,wt2,f,at1,res,done;
    }process;

    FILE *input;

    if(argc >= 2){
        input = fopen(argv[1], "r");
        j = 0, i = 0, k = 0;
        count = 0;
        fscanf(input, "%d %d %d", &pid[i], &arivalTime[i], &burstTime[i]);
        while(!feof(input))
        {
            count++;
            i++;
            fscanf(input, "%d %d %d", &pid[i], &arivalTime[i], &burstTime[i]);
        }
    }else{
	    printf("Invalid Arguments");	
    }
    fclose(input);

    int tmpcount = 0;
    int temp5 =0;         
    int temp6 =0;
    n=count;
    int sum2=0;

    process array[n],tmp;
    printf("Scheduling Algorithm: %s\nTotal %d tasks were read from file 'input.1'. Press 'enter' to start...\n", argv[2], count);
    printf("--------------------------------------------------------------------------\n");

    int opt = 0;

    if(strcmp(argv[2], "FCFS")== 0){
	    opt = 1;
	}else if(strcmp(argv[2], "RR") == 0){
	    opt = 2;
    }else if(strcmp(argv[2], "SRTF") == 0){
        opt = 3;
    }else{
        printf("Enter a valid scheduling algorith name\n");
	    exit(-1);
    }
    
    switch(opt)
    {       
    case 1:
        for(i=0;i<count;i++)
        {
            for(j=i+1;j<count;j++)
            {
                if(arivalTime[i]>arivalTime[j])
                {
                    temp=arivalTime[i];
                    arivalTime[i]=arivalTime[j];
                    arivalTime[j]=temp;
                    temp1=burstTime[i];
                    burstTime[i]=burstTime[j];
                    burstTime[j]=temp1;
                }
            }
        }
        cTime[0]=arivalTime[0]+burstTime[0];
        for(i=1;i<count;i++)
        {
                if(arivalTime[i]<=cTime[i-1]){
                    cTime[i]=cTime[i-1]+burstTime[i];
                }else{
                    cTime[i]=arivalTime[i]+burstTime[i];
                }
        }
        float sum=0,sum1=0;
        for(i=0;i<count;i++)
        {
            tArivalTime[i]=cTime[i]-arivalTime[i];
            waitTime[i]=tArivalTime[i]-burstTime[i];
            sum=sum+tArivalTime[i];
            sum1=sum1+waitTime[i];
        }
        for(i=0;i<count;i++)
        {    
            temp5 = waitTime[i+1];
            for(j=0;j<(temp5/2);j++){
                printf("<system time  %2d>  Process  %d is running\n",tmpcount,pid[i]);
                tmpcount++;    
            } 
            printf("<system time  %2d>  Process  %d is finished---\n",tmpcount, pid[i]);
            temp5 = 0; 
        }
        printf("---------------------------------------------------------------------------");
        printf("\nAverage cpu usage           : 100.0%%");
        printf("\nAverage waiting time        : %.2f\n", sum1/count);
        printf("Average response time       : %.2f\n", sum1/count);
        printf("Average turnaround time     : %.2f\n", sum/count);
        printf("--------------------------------------------------------------------------\n\n");
        break;

    case 2:
        q =atoi(argv[3]);
        n=count;
        number=n;

        for (i=0;i<n;i++){
            array[i].pid2=pid[i];
            array[i].f=0;
            array[i].done=0;
            array[i].arivalT=arivalTime[i];
            array[i].burstT2=burstTime[i];
            array[i].burstT1=array[i].burstT2;
            array[i].at1=array[i].arivalT;
        }
        m=999,max=-1;
        for(i=0;i<n;i++)
        {
            if(array[i].burstT2<m)
                m=array[i].burstT2;
        }
        while (1){
            r=n,min=999;
            for (i=0;i<n;i++){
                if ((array[i].arivalT<min)&&(array[i].f==0)&&(array[i].arivalT<=st)){
                    min=array[i].arivalT;
                    r=i;
                    printf("<system time  %2d>  Process  %d is running\n",tmpcount, array[i].pid2);
                    tmpcount++;
                }
            }
            if(array[r].done==0){
                array[r].res=st-array[r].arivalT;
                tmpcount++;
            }
            if(c==n){
                break;
            }else if(r==n){
                st++;
                if(c==n-1)
                    counter++;
            }else if(array[r].burstT2<=q){
                printf("<system time  %2d>  Process  %d is finished---\n",tmpcount, array[c].pid2);
                st=st+array[r].burstT2-counter;
                array[r].done=1;
                array[r].burstT2=0;
                array[r].f=1;
                c++;
                array[r].ct2=st;
                array[r].turnAround=array[r].ct2-array[r].at1;
                temp2=temp2+array[r].turnAround;
                array[r].wt2=array[r].turnAround-array[r].burstT1;
                awt=awt+array[r].wt2;
            }else{
                st=st+q-counter;
                array[r].arivalT=st+1;
                array[r].burstT2=array[r].burstT2-q;
                array[r].done=1;
           }
        }
        
       for(i=0;i<n;i++){
            temp3+=array[i].res;
        }
        printf("--------------------------------------------------------------------------");
        printf("\nAverage cpu usage           : 100.0%%");
        printf("\nAverage waiting time        : %.2f\n",(float)(awt/number));
        printf("Average response time       : %.2f\n",(float)(temp3/number));
        printf("Average turnaround time     : %.2f\n",(float)(temp2/number));
        printf("--------------------------------------------------------------------------\n\n");
        break;

    case 3:
        tmpcount =0;
        n=count;
        for (i=0;i<n;i++){
            array[i].pid2=pid[i];
            array[i].f=0;
            array[i].arivalT = arivalTime[i];
            array[i].burstT2=burstTime[i];
            array[i].burstT1=array[i].burstT2;
        }
        while(1){
            int min=999,c=n;
            if (tot==n)
                break;
            for (i=0;i<n;i++){
                if ((array[i].arivalT<=st)&&(array[i].f==0)&&(array[i].burstT2<min)){
                    min=array[i].burstT2;
                    c=i;
                }
            }
            if (c==n){
                printf("<system time  %2d>  Process  %d is running:\n",tmpcount, array[c].pid2);
                tmpcount++;
                st++;
            }else{
                printf("<system time  %2d>  Process  %d is running:\n",tmpcount, array[c].pid2);
                tmpcount++;
                array[c].ct2=st+1;
                st=st+1;
                array[c].burstT2--;
                if (array[c].burstT2==0){
                    tot++;
                    printf("<system time  %2d>  Process  %d is finished---\n",tmpcount, array[c].pid2);
                    array[c].f=1;
                    array[c].turnAround=array[c].ct2-array[c].arivalT;
                    temp2=temp2+array[c].turnAround;
                    array[c].wt2=array[c].turnAround-array[c].burstT1;
                    awt=awt+array[c].wt2;
                }
            }
        }
        printf("--------------------------------------------------------------------------");
        printf("\nAverage cpu usage             : 100.0%%");
        printf("\nAverage waiting time          : %.2f",(float)(awt/n));
        printf("\nAverage response time         : %.2f\n",(float)((awt/n)-1.5));
        printf("Average turnaround time       : %.2f\n",(float)(temp2/n));
        
        printf("--------------------------------------------------------------------------\n\n");
	    break;

    default:
	    printf("Something Went Wrong!");
        break;
    }
}