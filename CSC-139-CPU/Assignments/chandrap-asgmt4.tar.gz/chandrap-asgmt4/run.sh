#!/bin/bash

gcc Assignment4.c
./a.out input1.txt FIFO
./a.out input1.txt LRU
./a.out input1.txt OPT
