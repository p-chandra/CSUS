#include <stdlib.h>
#include <stdio.h>
#include <string.h>


void insertionSort(int arr[], int n) 
{ 
    int i, key, j; 
    for (i = 1; i < n; i++) { 
        key = arr[i]; 
        j = i - 1; 
        while (j >= 0 && arr[j] > key) { 
            arr[j + 1] = arr[j]; 
            j = j - 1; 
        } 
        arr[j + 1] = key; 
    } 
} 

void printArray(int arr[], int n) 
{ 
    int i; 
    for (i = 0; i < n; i++) 
        printf("%d ", arr[i]); 
    printf("\n"); 
} 

int main(int argc, char** argv) {
    int final[argc-2];
    int sum = 0;
    int head = 50;
    if(strcmp(argv[1], "FCFS") == 0)
    {
        int i, dist;
        for(i=2; i<argc; i++){
            final[i-2] = atoi(argv[i]);
            if(final[i-2] > 100 || final[i-2] < 0){
                printf("Integer is not inside 0 - 100\n");
                exit(-1);
            }
        }
        for(i=0; i<argc-2; i++){
            printf("Reading Track: %d\n",final[i]);
            dist = abs(head - final[i]);
            head = final[i];
            sum = dist + sum; 
        }
        printf("Total Distance: %d\n", sum);


    }else if(strcmp(argv[1], "SSTF") == 0){
        int i, j, min, count = 0;
        int dist = 0, sum = 0;
        for(i=2; i<argc; i++){
            final[i-2] = atoi(argv[i]);
            if(final[i-2] > 100 || final[i-2] < 0){
                printf("Integer is not inside 0 - 100");
                exit(-1);
            }
        }
        for(j=0; j<argc-2; j++){
            int max = 200;
            for(i=0; i<argc-2; i++){
                min = abs(final[i] - head);
                if(min < max){
                    max = min;
                    count = i;
                }
            }
            int temp = head;
            head = final[count];
            dist = abs(temp - head)+dist;
            final[count] = 300;
            printf("Reading Track: %d\n",head);
        }
        printf("Total Distance: %d\n",dist);


    }else if(strcmp(argv[1], "LOOK") == 0){
        int i;
        for(i=2; i<argc; i++){
            final[i-2] = atoi(argv[i]);
            if(final[i-2] > 100 || final[i-2] < 0){
                printf("Integer is not inside 0 - 100");
                exit(-1);
            }
        }
        insertionSort(final, argc-2);
        //printArray(final, count);
        int temp = head;
        int k, l;
	int dist = 0;
	l = argc-3;
        k = 0;
        while(l>=0){
            //printf("%d\n",final[k]);
            if(final[l]<=head){
                printf("Reading Track: %d\n", final[l]);
                dist = abs(temp - final[l]) + dist;
                temp = final[l];
            }
            l--;
        }
        while(k<argc-2){
            //printf("%d\n",final[k]);
            if(final[k]>head){
                printf("Reading Track: %d\n", final[k]);
                dist = abs(temp - final[k]) + dist;
		temp = final[k];
            }
            k++;
        }
       printf("Total Distance: %d\n", dist);
    }else{
            printf("Invalid argument\n");
    }
}
//5 28 10 7 39 20 45 67 36 35
