To compile use gcc
 - gcc Assignment5.c

To Run
   ./a.out FCFS 5 28 10 7 39 20 45 67 36 35
   ./a.out SSTF 5 28 10 7 39 20 45 67 36 35
   ./a.out LOOK 5 28 10 7 39 20 45 67 36 35

The program will not take inputs outside of the bounderies 0 - 100
and FCFS SSTF LOOK are case sensitive
