#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>

#define LB_SIZE 80


	int X(void);
	int Y(void);
	int Z(int a,int b);
	void sampleLoadAvg(void);

	char c1,c2;	
	char *lineBuff; 
	int interval;		
	int duration;
	struct timeval now, now2;  
	time_t curtime;
	int day, hour, minute, second;

	
	int main( int argc, char *argv[])
	{
		lineBuff = (char *)malloc(LB_SIZE + 1);
		if (argc == 1)
		{ 
			return X();
		}
		if (argc > 1)
		{
			sscanf(argv[1],"%c%c",&c1,&c2);
			if (c1 != '-')
			{
				printf("Usage:./observer   [-s] [-l int dur]\n");
				exit(1);
			}
		}
		if (c2 == 's')
		{ 
			X();
			return Y();
		}
		if (c2 == 'l')
		{ 
			if ( argc < 4 )
			{
				printf("Usage:observer  [-s] [-l int dur]\n");
				exit(1);
			}
			return Z(atoi(argv[2]),atoi(argv[3]));
		}	
	}
	
/*----------------------------------------------*/
	int X(void){

		printf("2.2 Part B");
		char * tokens[16];
		struct utsname buffer;
		
		FILE *fp = fopen("/proc/cpuinfo","r");
			
			if (fp == NULL)
			{
				perror("open file error!");
				return -1;
			}
			while (fgets(lineBuff,LB_SIZE + 1,fp) != NULL)
			{
				if ( strncmp(lineBuff,"model name",10) == 0)
				{
				printf("\n%s",lineBuff);
				break;
				}
			}	
			fclose(fp);	
	   
			if (uname(&buffer) != 0) 
			{
				perror("uname");
				exit(EXIT_FAILURE);
			}
				printf("Kernel Version:\t %s\n", buffer.version);   
				printf("Kernel hostname:\t %s\n", buffer.nodename);
	
				gettimeofday(&now,NULL);
				printf("Current Time:\t%s",ctime(&(now.tv_sec)));
	
				int days, hours, mins;
				struct sysinfo sys_info;

				if(sysinfo(&sys_info) != 0)
				perror("sysinfo");

			 
				days = sys_info.uptime / 86400;
				hours = (sys_info.uptime / 3600) - (days * 24);
				mins = (sys_info.uptime / 60) - (days * 1440) - (hours * 60);
				printf("Uptime: %ddays, %dhours, %dminutes, %ldseconds\n", days, hours, mins, sys_info.uptime % 60);

	}
	
	
/*---------------------------------*/	

	
		int Y(void)
		{
		
			printf("2.3 Part C");
			FILE *fp = fopen("/proc/stat","r");
			if (fp == NULL)
			{
				perror("open file error!");
				return -1;
			}
			
			int i = 0;
			int cpu_count = -1;
			char * tokens[16];
			char * table_head[16] = {"   ","nice(user)","System","idle"};

			while (fgets(lineBuff,LB_SIZE + 1,fp) !=NULL)
			{
				if ((strncmp(lineBuff,"cpu",3) == 0)&&(!(strncmp(lineBuff,"cpu1",4)==0))&&(!(strncmp(lineBuff,"cpu2",4)==0))&&(!(strncmp(lineBuff,"cpu3",4)==0))&&(!(strncmp(lineBuff,"cpu0",4)==0)))   
				{   
					tokens[0] = strtok(lineBuff," "); 
					for ( i=1; (tokens[i]=strtok(NULL," "))!=NULL;++i);
						if (++cpu_count == 0)
						{
								printf("--------- CPUStat ---------\n");
								printf("%s",table_head[0]);
								for (i = 1;i<= 3;++i)
								{
									printf("\t|%10s",table_head[i]);
								}
								printf("\n");
								printf("Total");
						}
						else
						{
							printf("CPU%d",cpu_count);
						}
						for (i = 1;i <= 4; ++i)
						{
							printf("\t|%10s",tokens[0]);
							printf("\t|%10s",tokens[1]);
							printf("\t|%10s",tokens[2]);
							printf("\t|%10s",tokens[3]);
							printf("\t|%10s",tokens[4]);
						}
						printf("\n");
						continue;
				}
				if (strncmp(lineBuff,"intr",4) == 0)
					{
						printf("total disk requests: %d\n",atoi(lineBuff + 4));
						continue;
					}
					if (strncmp(lineBuff,"ctxt",4) == 0)
					{
						printf("total context switches: %d \n",atoi(lineBuff + 4));
						continue;
					}
					if (strncmp(lineBuff,"btime",5) == 0)
					{
						printf("total boot time in secs: %d \n",atoi(lineBuff + 6));
						continue; 
					}
					if (strncmp(lineBuff,"processes",9) == 0)
					{
						printf("total process created: %d\n",atoi(lineBuff + 9));
						continue;
					}
			}
				fclose(fp);
		
		}
		
/*---------------------------------------*/	

	int Z(int a,int b)
	{
		double interval = a;		
		double duration = b;		
		unsigned int iteration = 0;
		FILE *fp;
		unsigned int sec = 0;
		unsigned int min = 0;
		unsigned int msec = 0;
		unsigned int hour = 0;
		unsigned int second = 0;
		unsigned int time_taken;

			clock_t t;
			

			second= (unsigned int)(duration);
			

			fp = fopen("/proc/meminfo","r");
			if (fp == NULL)
			{
				perror("cannot open /proc/meminfo");
				return -1;
			}

			while (fgets(lineBuff,LB_SIZE +1,fp) != NULL)
			{
				if( strncmp(lineBuff,"MemTotal",8) == 0)
				{
					printf("Memtotal\t:%30.30s",lineBuff + 8 + 1);
				}
				if (strncmp(lineBuff,"MemFree",7) == 0)
				{
					printf("Memfree\t:%30.30s",lineBuff + 7 + 1);
				}
			}
				fclose(fp);
				
			fp = fopen("/proc/loadavg","r");

					
			t = clock();
			

			fp = fopen("/proc/loadavg","r");
			duration = second-sec;
			
		
			printf("Please wait. This program will run for %d sec\n and sampling every %d sec for an average\n--------------\n", b, a); 
			while (b>0)
			{
					fgets(lineBuff,LB_SIZE + 1,fp);
					printf("%s",lineBuff);
					fclose(fp);
					fp = fopen("/proc/loadavg","r");
					iteration+=(unsigned int)(interval);		
					sleep(a);
					b-= a;
		
			}

	}
		 
	
/*-----------------------------------------------------------*/
