In order to run this program, I have all the C files uplaoaded to the linux server. 

Type in gcc csc139_lab1.c to compile the codde. 

Then a.out to run the code.

Part B of teh assignment will start with a.out
Part C of the assignment will start with a.out - c.
Part D of the assignmnet will start with a.out -1 10 600. 

