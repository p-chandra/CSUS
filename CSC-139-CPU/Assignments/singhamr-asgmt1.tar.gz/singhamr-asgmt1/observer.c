
/*
 * Amrit singh
 * csc 139 - Operating Systems
 * Assignment 1: Observing Linux Behaviour
 * Grace Days Used: 2
 * Due Date: 2/21/19
 * Submitted: 2/23/19
 *
 * This assignment used various calls to display information regarding the linux kernel, boot info, and other various CPU statistics.
 * */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#define LB_SIZE 20
#define LONG "long"
#define SHORT "short"
#define STANDARD "standard"

int main(int argc, char *argv[])
{

  int iteration = 0;
  int interval = 0;
  int duration = 0;
  int count = 0;
  int secondTime, minuteTime, hourTime, dayTime, boot_time;
  int userMode, systemMode, idleMode, filler; 
  int readsCompleted, writesCompleted, contextswitch, b_time, process;
  int configuredMemory, freeMemoryint;
  char repTypeName[16];
  char c;
  char c1[1];
  char lineBuf[LB_SIZE];
  char *reportType = STANDARD;
  char line[1000];
  FILE *thisProcFile;
  FILE *cpuinfo = fopen("/proc/cpuinfo", "r");
  FILE *version = fopen("/proc/version", "r");
  FILE *uptime = fopen("/proc/uptime", "r");
  FILE *statisticsUSI = fopen("/proc/stat", "r");
  FILE *readWrite = fopen("/proc/diskstats", "r");
  FILE *contextSwitches = fopen("/proc/stat", "r");
  FILE *checkBootTime = fopen("/proc/stat", "r");
  FILE *processes = fopen("/proc/stat", "r");
  FILE *configMemory = fopen("/proc/meminfo", "r");
  FILE *freeMemory = fopen("/proc/meminfo", "r");

  struct timeval now;
/*run through the cpuinfo file and grab relevant lines */

  while ((fgets(line, sizeof(line), cpuinfo)))
  {
    count++;
    if (count == 5)
	printf("CPU %s\n", line); /*grabs the line in cpuinfo and prints it*/
    
  }


/*run through version file and grab relevant lines*/

  while ((c = fgetc(version)) != EOF) /*grabs kernel version*/ 
  {
    printf("%c", c);
  }

  printf("\n"); 


  while ((fgets(line, sizeof(line), uptime)))
  {
    sscanf(line, "%d", &boot_time);
    dayTime = boot_time / 60 / 60 / 24;
    hourTime = boot_time / 60 / 60 % 24;
    minuteTime = boot_time / 60 % 60;
    secondTime = boot_time % 60;
    printf("Boot time: %02d:%02d:%02d:%02d\n\n",dayTime, hourTime, minuteTime, secondTime);
  }

/*prints report type and time*/
  strcpy(repTypeName, "Standard");
  if (c1[1] == 's')
  {
    reportType = SHORT;
    strcpy(repTypeName, "Short");
  }else if (c1[1] == 'l'){
    reportType = LONG;
    strcpy(repTypeName, "Long");

  }

  gettimeofday(&now, NULL); 
  printf("Status Report Type %s at %s\n", repTypeName, ctime(&(now.tv_sec)));


/*print hostname*/

  thisProcFile = fopen("/proc/sys/kernel/hostname", "r");
  fgets(lineBuf, LB_SIZE + 1, thisProcFile);
  printf("Machine hostname: %s\n", lineBuf);
  fclose(thisProcFile);


/* prints what is neccessary for parts C and D*/
  if (argc > 1)
  {
    sscanf(argv[1], "%s", c1);
    if (c1[0] != '-')
    {
      fprintf(stderr, "usage: observer [-s][-l int dur]\n");
      exit(1);
    }
	/* part C*/
    if (c1[1] == 's')
    {
      reportType = SHORT;
      strcpy(repTypeName, "Short");

	/* print usermode, systemmode, idle mode stats*/

      fgets(line, sizeof(line), statisticsUSI);
      sscanf(line, "cpu %d %d %d %d", &userMode, &filler, &systemMode, &idleMode);
      printf("User mode:%d\n", userMode);
      printf("\n");
      printf("System mode:%d\n", systemMode);
      printf("\n");
      printf("Idle mode:%d\n\n", idleMode);

	/* checks for reads and writes completed*/
      count =0;
      while ((fgets(line, sizeof(line), readWrite)))
      {
        count++;
        if (count == 26)
        {
          sscanf(line, "%d %d %s %d %d %d %d %d", &filler, &filler, &filler, &readsCompleted, &filler, &filler, &filler, &writesCompleted);
          printf("Reads Completed: %d\n", readsCompleted);
          printf("\n");
	  printf("Writes Completed: %d\n\n", writesCompleted);
        }
      }
          printf("Context Switches: %d\n\n", contextswitch);
       


	/* checks for context switches performed */
      count =0;
      while ((fgets(line, sizeof(line), contextSwitches)))
      {
        count++;
        if (count == 11)
        {
          sscanf(line, "%s %d", &filler, &contextswitch);
        }
      }
       


	/*  checks for boot time */
      count =0;
      while ((fgets(line, sizeof(line), checkBootTime)))
      {
        count++;
        if (count == 12)
        {
          sscanf(line, "%s %d", &filler, &b_time);
          printf("Boot Time: %d\n\n", b_time);
        }
      }
          printf("Processes: %d\n\n", process);
	 

	/*  checks the number of processes that have been created  */
      count =0;
      while ((fgets(line, sizeof(line), processes)))
      {
        count++;
        if (count == 13)
        {
          sscanf(line, "%s %d", &filler, &process);
          printf("Processes: %d\n\n", process);
        }
      }


    }
/* Part D*/
    if (c1[1] == 'l')
    {

      if (argv[2] == NULL || argv[3] == NULL)
      {
        fprintf(stderr, "usage: observer [-s][-l int dur]\n");
        exit(1);
      }
      else
      {
        reportType = LONG;
        strcpy(repTypeName, "Long");
        interval = atoi(argv[2]);
        duration = atoi(argv[3]);
      }

      fgets(line, sizeof(line), configMemory);
      sscanf(line, "%s %d", &filler, &configuredMemory);
      printf("Memory Configured:%d\n\n", configuredMemory);

      count =0;
      while ((fgets(line, sizeof(line), freeMemory)))
      {
        count++;
        if (count == 2)
        {
          sscanf(line, "%s %d", &filler, &freeMemoryint);
          printf("Memory Available:%d\n\n", freeMemoryint);
        }
      }
      while (iteration < duration)
      {
        sleep(interval);
        FILE *loadavg = fopen("/proc/loadavg", "r");
        fgets(line, sizeof(line), loadavg);
        printf("Interval: %d Iteration: %d Load Average: %s", interval, iteration, line);
        iteration += interval;
      }
      return (0);

    }

  }

}
