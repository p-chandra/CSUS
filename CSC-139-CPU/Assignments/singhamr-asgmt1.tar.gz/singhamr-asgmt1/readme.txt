For this program to run you need to compile the code using
 -gcc observer.c

the code should run for part B when you use
	a.out 
the code should run for part C when you use 
	a.out -s
the code should run for part D when you use
	a.out -l (followed by any two parameters)
	E.G. (a.out -1 2 60)