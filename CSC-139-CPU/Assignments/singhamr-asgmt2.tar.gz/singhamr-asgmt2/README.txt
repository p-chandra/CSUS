Round Robin was not implemented in this code.
 


In order to compile the code, type gcc mainntest.c.

To run the code 
 type

--
   a.out input.1 srtf 

   
a.out input.1 fcfs







