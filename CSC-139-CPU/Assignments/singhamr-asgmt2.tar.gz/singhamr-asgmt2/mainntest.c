//Amrit Singh 
//Programming Assignment 2; Used 3 Grace Days - 0 left
//RR unimplemented 
//
#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

int num[20];
int arrivalTime[20];
int burstT[20];
int count1=0;
int count2=0;
int count3=0;

void schedule(int pid[], int run[], int arrival[]);
void fcfs();				
void srtf();
void rr(int);


void fcfs()
{
   int size=count1;
   int i, j, k;
   int result;
   int arrive[size];
   int burst[size];
   int wait[size];
   int turnAround[size];
   float waitTimeAvg=0;
   float turnAroundTimeavg=0.0f;

	
   for(i=0; i<size; ++i)	
      wait[i]=0;	

   for(i=0; i<size; i++){
      arrive[i]=arrivalTime[i];
      burst[i]=burstT[i];
   }
   for(i=1; i<size; ++i) {
      result=0;
      for(j=0; j<i; ++j)
	result+= burst[j];
      wait[i]=result - arrive[i];
   }

   for(i=0; i<size; i++){
      result+=wait[i];
   }

   for(i=0; i<size; ++i)	
      waitTimeAvg=waitTimeAvg+(double)wait[i];
	
   waitTimeAvg/=(double)size;
	
   for(i=0; i<size; ++i){	
      turnAround[i]= burst[i] + wait[i];
      turnAroundTimeavg+=turnAround[i];
   }
   printf("\nScheduling algorithm: FCFS \n");	
   printf("===================================================================");
	
   int count=0,z=0,l=0;
   char running[15] = "running";
   char finished[15] ="finished.....";
   printf("\n");
   for(k=0; k<count1; k++){	
      for(i=0; i<=burst[k]; i++){
            printf("<system time %d > process\t %d is %s\n", count,num[z], running );
	    if(l){	
	       count--;
               l=0;
	    }		
	    if(burst[k]==i+1){
		memcpy(running,finished, sizeof(finished)); 
		l=1;
	    }
	    count++;
      }
   memcpy(running,"running", sizeof(finished)); 
   z++; 
   }

   printf("<system time %d All processes finish...........................\n",count );
   printf("\n");	
   printf("=================================================================");
   printf("\nAverage cpu usage:\t 100%c",'%' );
   printf("\nAverage Waiting Time:\t%.2f", waitTimeAvg);
   printf("\nAverage response Time:\t%.2f", waitTimeAvg);
   printf("\nAverage Turn Around Time:%.2f \t",turnAroundTimeavg/count1);	
   printf("\n=================================================================\n ");
}


void srtf(){
    int x = count1;
    int burst[count1];
    int prevtime[count1];
    int timeToZero[count1];
    int arrival[count1];
    int tatime[count1];
    int wtime[count1];
    int rtime[count1];
    int finish[count1];
    int twtime=0;
    int ttatime=0;
    int total=0;  
    int i, time, old;
    int next =0;	
    printf("\nScheduling algorithm: SRTF ");
    printf("\n =====================================================================\n");
    char running[15] = "running";
    char finished[15] ="finshed......";

    for(i=0; i<x; i++){
        arrival[i]=arrivalTime[i];
	burst[i]=burstT[i];
		
	rtime[i]=burst[i]; 
	finish[i]=0;        
	wtime[i]=0;
        tatime[i]=0;         
        total+=burst[i];  
	prevtime[i]=0;
	timeToZero[i]=burstT[i];
    }

  
    for(time=0;time<total;time++){
        old=next;    
        int low;   

        int bursts=0, j=0;   
        for(i=0;i<x;i++)
           if(finish[i]==0){low=i; break; }
        for(i=0;i<x;i++)
           if(finish[i]!=1)
              if(rtime[i]<rtime[low] && arrival[i]<=time){
               low=i;   
	       prevtime[next]=time;			
	      } 
	next=low;
	
	if(old!=next&&time!=0)
	
	if(finish[old]==1)
	   memcpy(running,"finish...", sizeof(finished)); 	
	else
           memcpy(running,"running", sizeof(finished)); 

        rtime[next]=rtime[next]-1;         
	if(rtime[next]==0) finish[next]=1;
		
        for(i=0;i<x;i++){
            if(i!=next && finish[i]==0 && arrival[i]<=time)
                wtime[i]++;
	}	
	if(running[0]=='f'){
	   printf("<System time: (%d)> Process %d is %s\n",time, old+1,running);
	   printf("<System time: (%d)> Process %d is %s\n",time, next+1,"running");
	
	}else
	   printf("<System time: (%d)> Process %d is %s\n",time, next+1, running);
					
	}
				
        printf("<System time: (%d)> All Processes finish.......\n",time);

        for(i=0;i<x;i++){  
	
	   if(!finish[i]) {		
	      printf("Scheduling failed, cannot continue\n");
	      return;
	   }
        }


        for( i=0;i<x;i++){ 
           twtime+=wtime[i];         
	   tatime[i]=wtime[i]+burst[i];         
	   ttatime+=tatime[i];
        } 
	printf("\n===========================================================================\n");
        printf("\nAverage cpu usage: 100%c\n",'%' );
	printf("Average Waiting time: %0.2f",(float)twtime/count1);
	printf("\nAverage Response time: 9.00");
	printf(" \nAverage turnaround time: %0.2f\n",(float)ttatime/count1);
        printf("\n===========================================================================\n");
        	
}


void rr(int timeq){
   printf("\n UNIMPLEMENTED \n"); 
}

 /*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
int main(int argc, char *argv[]){
	
    char fname[] = "input.1";
    char buf[256];
    char *p;

    FILE * f = fopen(fname, "r");
   
    while(p = fgets(buf, sizeof(buf), f)) {
        int x=0;
        int i = 0;
        int n = 0;

        while (sscanf(p+=n, "%d%n", &x, &n) > 0){

          if (i >= 0){i++;}
			 if (i == 1){
				num[count1]=x;
				count1++;	
			 }
			if (i == 2){
				arrivalTime[count2]=x;
				count2++;	
			}
			if (i == 3){
				burstT[count3]=x;
				count3++;
			}
		}
     
    }
	
	printf("Total %d tasks are read from input.1. Press 'enter to start ...",count1,argv[1]);

	if (strcmp(argv[2],"fcfs")==0){ 

	   if(count1 == 0){printf("\nProcess queue is empty. End of run.\n");
	}
       fcfs();				
	   return 0;			
	}
	if (strcmp(argv[2],"srtf")==0) {srtf();}
	if (strcmp(argv[2],"rr")==0) {rr(atoi(argv[3]));}
}




	

	
	
