//Amrit Singh
//Assignmennt 3: Process Synchronization
//CC 139 Operating System Principles - Spring 2019
//Submitted on time

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include "buffer.h"
#include <pthread.h>

#define RANDCAP 5
#define TRUE 1

pthread_mutex_t mutex;
sem_t full, empty;

buffer_item buffer[BUFFER_SIZE];

int first, last;
int c;
pthread_t tid;  
pthread_attr_t attr; 
void *producer(void *param); 
void *consumer(void *param); 
/*------------------ insert item ----------------------------------------------------- */
int insert_item(buffer_item item) {

/* inserts item into buffer
 * returns 0 if successful, otherwise
 * return -1 indicating and error condition  */  
   if(c < BUFFER_SIZE) {
      buffer[c] = item;
	last = (last + 1) % BUFFER_SIZE;
      c++;
      return 0;

   }else 
      return -1;
}

/* ------------------   remove item---------------------------------------------*/
int remove_item(buffer_item *item) {
/* remove an object from buffer
 * placing it in item
 * return 0 if succesfull, otherwise
 * return -1 indicating an error condition     */

   if(c > 0) {
      *item = buffer[(c-1)];
      first = (first + 1) % BUFFER_SIZE;
      c--;
      return 0;
   }else 
      return -1;

}
/*  ----Initialize Buffer------------------------------------------------------------------------*/
void initializeBuffer() {

/*buffer requiers and initilization function that initializes the mutex
 *  along with the empty and full semaphores
 *  main function initializes the buffer and creates seperate producer consumer threads */
   pthread_mutex_init(&mutex, NULL);
   sem_init(&full, 0, 0);
   sem_init(&empty, 0, BUFFER_SIZE);
   pthread_attr_init(&attr);
   c = 0;

}

/*-------Main-----------*/

int main(int argc, char *argv[]) {
/*1. Get command line arguments argv[1],argv[2],argv[3]*/
/*2. Initialize buffer*/
/*3. Create producer thread(s)*/
/*4. Create consumer thread(s)*/
/*5. Sleep*/
/*6. Exit*/
   int i;
   int mainSleepTime = atoi(argv[1]);
   int numProd = atoi(argv[2]);
   int numCons = atoi(argv[3]);

   if(argc != 4) {
      fprintf(stderr, "USAGE:./main.out <INT> <INT> <INT>\n");
   }
 

   initializeBuffer();


   for(i = 0; i < numProd; i++) {
      pthread_create(&tid,&attr,producer,NULL);
    }

   for(i = 0; i < numCons; i++) {

      pthread_create(&tid,&attr,consumer,NULL);

   }
   sleep(mainSleepTime);

   printf("Exit the program\n");

   exit(0);

}

/* producer code given by professor --------------------------------*/
void *producer(void *param) {

	buffer_item item;
	while (TRUE) {
	/*sleep for a random period of time*/
	   int rNum = rand() % RANDCAP+1;
	   sleep(rNum);
	/*generate a random number*/
	   item = rand() %123+1;
	   sem_wait(&empty);
	   pthread_mutex_lock(&mutex);
	   if (insert_item(item))
	      fprintf(stderr, "report error condition\n");
	   else
	      printf("producer produced %d\n",item);

      	   pthread_mutex_unlock(&mutex);
      	   sem_post(&full);
	}
}
/*  --------------------------------------------------------------------- */

/*  consumer code given by professor---------------------------------------- */

void *consumer(void *param) {

	buffer_item item;
	while(TRUE){
   	   int rNum = rand() % RANDCAP+1;
	/*sleep for a random period of time*/
           sleep(rNum);
	   sem_wait(&full);

	/*acquire the mutex lock*/
           pthread_mutex_lock(&mutex);
	   if(remove_item(&item)) 
              fprintf(stderr, "Consumer report error condition\n");
      	   else 
              printf("consumer consumed %d\n", item);

	/*release the mutex lock*/
           pthread_mutex_unlock(&mutex);
	   sem_post(&empty);

	}

}

