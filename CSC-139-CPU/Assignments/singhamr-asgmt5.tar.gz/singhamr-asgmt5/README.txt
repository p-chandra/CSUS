
Amrit Singh CSC 139 Asgmt5

Please use this to replace the 4th programming assignment. I was not able to complete it in the given time due to other class pojects being due around the same time. Thank you.

To run the program open terminal and run the following commands. 

gcc fcfs.c

a.out  5 28 10 7 39 20 45 67 36 35

or

gcc sstf.c

a.out  5 28 10 7 39 20 45 67 36 35

or 

gcc look.c

a.out  5 28 10 7 39 20 45 67 36 35