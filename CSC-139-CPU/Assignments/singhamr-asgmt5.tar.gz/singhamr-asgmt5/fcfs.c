 #include <ctype.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>

int main(int argc, char *argv[])
{
	int totalDist = 0;
	int i =0;
    	if (argc<2){	
		printf("please provide arguments\n");
		return 0;
	}
	for ( i = 1; i < argc; i++)
	{
		printf("Reading Track %s\n", argv[i]);
		totalDist+=atoi(argv[i]);
	}	
	printf("Total Distance: %i\n",totalDist);
        return 0;
}

