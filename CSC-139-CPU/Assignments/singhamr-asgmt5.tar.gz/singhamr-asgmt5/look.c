 #include <ctype.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>



void ascending(int arr[],int len){
   int i=1;
   for ( i = 1; i < len; i++){ 
      int tmp = arr[i];
      int j=0;
      for ( j=i; j>0 && tmp < arr[j-1]; j--){
         arr[j] = arr[j-1];
      }
      arr[j] = tmp;
   }
	for (i=0;i<len;++i){
		printf("Reading track %i\n",arr[i]);
	}

}

void descending(int arr[],int len){
 int i=1;
   for ( i = 1; i < len; i++){ 
      int tmp = arr[i];
      int j=0;
      for ( j=i; j>0 && tmp > arr[j-1]; j--){
         arr[j] = arr[j-1];
      }
      arr[j] = tmp;
   }
	for (i=0;i<len;++i){
		printf("Reading track %i\n",arr[i]);
	}


}
int print(int arr[],int len){
	int i=0;
	for ( i=0;i<len;++i){
		printf("%i ",arr[i]);
	}
	printf("\n");
	return 0;
}
int main(int argc, char *argv[])
{
	int l=argc-1;
	int *arr=(int *)malloc(sizeof(int)*l);
	int up=0;
	int down=0;
	int totalDistance=0;
	int i=0;
	int first=atoi(argv[1]);
	
	if (argc<2){	
		printf("No arguments given\n");
		return 0;
	}
	printf("Default Direction goes upwards\n");

	printf ("Reading track %i\n",first);

	

	    for ( i = 0; i < argc-1; i++) {
		arr[i]=atoi(argv[i+1]);
		totalDistance +=arr[i];
		if (i!=0){
			if (arr[i]>=first)
				up++;
			else
				down++;
		}
		
	    }

	int *arr_up=(int *)malloc(sizeof(int)*up);
	int *arr_down=(int *)malloc(sizeof(int)*down);
	int x=0;
	int y=0;
	for (i=1,x=0,y=0;i<l;++i){
		if (arr[i]>=first)
			arr_up[x++]=arr[i];
		else
			arr_down[y++]=arr[i];
			
	}	

	ascending(arr_up,up);
	descending(arr_down,down);
	printf("Total Distance: %i\n",totalDistance);
    return 0;
}


