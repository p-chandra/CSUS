 #include <ctype.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>


int main(int argc, char *argv[])
{
	if (argc<2){	
		printf("No Arguments\n");
		return 0;
	}
	int first=atoi(argv[1]);
	printf ("Reading Track %i\n",first);

	int l=argc-1;
	int *arr=(int *)malloc(sizeof(int)*l);
	int totalDistance=0;
	int i=0;
	    for ( i = 0; i < argc-1; i++) {
		arr[i]=atoi(argv[i+1]);
		totalDistance+=arr[i];
	    }

	
	for (i=0;i<l-1;++i){
		int Val= locateMinimum(arr[i],arr,l);
		printf("Reading track %i\n",arr[Val]);
		arr[Val]=-1;
		if (i==0)
			arr[i]=-1;

	}
	printf("Total Distance: %i\n",totalDistance);
    return 0;
}
int locateMinimum(int a, int b[],int len){
	int minimum=100000;
	int diff=100000;
	int i=0;
	for (i=0;i<len;++i){
		if (b[i]!=-1)
		if (abs(b[i]-a)<diff && a!=b[i]){
			minimum=i;
			diff=abs(b[i]-a);
		}
	}
	return minimum;
}

int print(int arr[],int len){
	int i=0;
	for ( i=0;i<len;++i)
		printf("%i ",arr[i]);
	printf("\n");
	return 0;
}

