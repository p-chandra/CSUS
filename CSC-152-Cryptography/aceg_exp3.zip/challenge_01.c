#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv) {
    char buf[40];
    int admin=0;

    printf("Enter Password: ");
    fflush(stdout);
    read(0, &buf, 30);
    
    if (admin == 29845) {
        printf("Welcome to the Mainframe!\n");
    } else {
        printf("ACCESS DENIED!\n");
    }
    return 0;
}
