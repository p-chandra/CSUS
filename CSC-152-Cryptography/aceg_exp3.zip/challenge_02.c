#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void do_admin(void) {
    system("/bin/sh");
}

int main(int argc, char **argv) {
    int admin=1337;
    char buf[40];

    printf("Enter Password: ");
    fflush(stdout);
    read(0, &buf, 100);
    
    if (admin == 29845) {
        printf("Welcome to the Mainframe!\n");
    } else {
        printf("ACCESS DENIED!\n");
    }
    return 0;
}
