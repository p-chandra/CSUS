#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int admin=0;

void do_admin(void) {
    if (admin == 31337) {
        system("/bin/sh");
    } else {
        printf("Admin functionality denied!\n");
        exit(-1);
    }
}

int main(int argc, char **argv) {
    char buf[80];

    printf("Thank you for visiting ACE Storage!\n Please let us know if you'd like us to store any data.\n");
    printf("Enter storage information: ");
    fflush(stdout);
    read(0, &buf, 100);
    printf("Thank you! Data stored at %016p\n", &buf);
    
    return 0;
}
