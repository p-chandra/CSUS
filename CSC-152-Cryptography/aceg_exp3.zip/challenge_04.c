// gcc filename.c -o filename -z execstack -fno-stack-protector -no-pie -Wl,-z,norelro
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void uppercase(char *input) {
    for (int i = 0; input[i] != 0; i++) {
        input[i] = toupper(input[i]);
    }

    printf("%s\n", input);
}

void lowercase(char *input) {
    for (int i = 0; input[i] != 0; i++) {
        input[i] = tolower(input[i]);
    }

    printf("%s\n", input);
}

void hex(char *input) {
    for (int i = 0; input[i] != 0; i++) {
        printf("%02x", input[i]);
    }

    printf("\n");
}

void base64(char *input) {
    FILE *fp = fopen("base64temp.txt", "w");    

    if (!fp) {
        puts("fopen failed");
        exit(-1);
    }

    fwrite(input, strlen(input), 1, fp);
    fclose(fp);

    system("base64 < base64temp.txt");
    system("rm base64temp.txt");
}

int main() {
    void (*handlers[4]) (char *input) = {
        uppercase,
        lowercase,
        hex,
        base64,
    };

    char strInput[100];
    int intInput;

    printf("Input a string: ");
    fgets(strInput, sizeof(strInput), stdin);

    int strLen = strlen(strInput);

    if (strLen > 0 && strInput[strLen - 1] == '\n') {
        strInput[strLen - 1] = 0;
    }

    puts("What would you like to do?");
    puts("\t[0] Uppercase string");
    puts("\t[1] Lowercase string");
    puts("\t[2] Hex encode string");
    puts("\t[3] Base64 encode string");

    scanf("%d", &intInput);

    handlers[intInput](strInput);
}
