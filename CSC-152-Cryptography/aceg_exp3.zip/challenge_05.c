// gcc filename.c -o filename -z execstack -z execstack -no-pie
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char stuff[0x1000] = { 0 };

int main() {
    char inputBuf[0x100];

    unsigned long long writeAddr;
    unsigned long long writeVal;

    while (1) {
        writeAddr = 0;
        writeVal = 0;

        memset(inputBuf, 0, sizeof(inputBuf));

        printf("Write address (In Hex): ");
        fgets(inputBuf, sizeof(inputBuf), stdin);

        writeAddr = strtoull(inputBuf, NULL, 16);

        printf("Write value (In Hex): ");
        fgets(inputBuf, sizeof(inputBuf), stdin);

        writeVal = strtoull(inputBuf, NULL, 16);

        *(unsigned long long *)writeAddr = writeVal;
    }
}
