// gcc filename.c -o filename -fno-stack-protector -no-pie
#include <stdio.h>
#include <stdlib.h>

struct data {
    void (*func)(char *);
    char input[8];
};

void stuff() {
    system("exit");
}

char inputBuf[64] = { 0 };
struct data *dataPtr = { NULL };

int main() {

    printf("> ");
    fgets(inputBuf, 100, stdin);

    if (dataPtr) {
        dataPtr->func(dataPtr->input);
    }
}
