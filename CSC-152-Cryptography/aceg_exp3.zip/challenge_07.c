#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

int canary_a;

void do_admin(void) {
    system("/bin/sh");
}

int main(int argc, char **argv) {
    char buf[30];

    srand(time(NULL));
    canary_a = rand();
    int canary = canary_a;

    printf("Welcome to my hacker proof system! Go ahead, give me anything!\n");
    printf("Enter username: ");
    fflush(stdout);
    read(0, &buf, 80);
    printf("Thank you! %s", buf);
    
    if (canary_a != canary) {
        printf("Haha, hacking detected! BE GONE!\n");
        exit(-1);
    }

    return 0;
}
