#!/bin/bash

gcc -fno-stack-protector -o challenge_01 challenge_01.c
gcc -fno-stack-protector -o challenge_02 challenge_02.c
gcc -fno-stack-protector -no-pie -z execstack -o challenge_03 challenge_03.c
gcc -z execstack -fno-stack-protector -no-pie -Wl,-z,norelro -o challenge_04 challenge_04.c
gcc -z execstack -z execstack -no-pie -o challenge_05 challenge_05.c
gcc -fno-stack-protector -no-pie -o challenge_06 challenge_06.c
gcc -m32 -fno-stack-protector -no-pie -o challenge_07 challenge_07.c
gcc -fno-stack-protector -o challenge_08 challenge_08.c
