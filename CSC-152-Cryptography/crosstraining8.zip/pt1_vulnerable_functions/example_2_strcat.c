// gcc example_2_strcat.c -o example_2_strcat -fno-stack-protector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void greet(char *name) {
    char buf[100];

    strcpy(buf, "Hi ");
    strcat(buf, name);
    strcat(buf, "!");

    puts(buf);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("%s <name>\n", argv[0]);
        exit(-1);
    }

    greet(argv[1]);
}
