// gcc example_3_sprintf.c -o example_3_sprintf -fno-stack-protector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void create_output(int input1, float input2, char *input3) {
    char output[100];

    memset(output, 0, sizeof(output));

    sprintf(output, "%d %f %s", input1, input2, input3);

    puts(output);
}

int main(int argc, char **argv) {
    int input1;
    float input2;
    char input3[100];

    input1 = 0;
    input2 = 0.0f;
    memset(input3, 0, sizeof(input3));

    puts("Enter an integer:");
    printf("> ");

    scanf("%d", &input1);
    // Handle extra newline
    getchar();

    puts("Enter a float:");
    printf("> ");

    scanf("%f", &input2);
    // Handle extra newline
    getchar();

    puts("Enter a string (Max 100 chars):");
    printf("> ");

    fgets(input3, sizeof(input3), stdin);

    create_output(input1, input2, input3);
}
