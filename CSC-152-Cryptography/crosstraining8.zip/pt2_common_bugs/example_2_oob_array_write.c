// gcc example_2_oob_array_write.c -o example_2_oob_array_write -fno-stack-protector
#include <stdio.h>

int main() {
    int index;
    const char *msgs[8] = {
        "1111",
        "2222",
        "3333",
        "4444",
        "5555",
        "6666",
        "7777",
        "8888"
    };

    char input[100];

    puts("Message Index:");
    printf("> ");

    scanf("%d", &index);

    puts("Message Value: ");
    printf("> ");

    // Read trailing newline that scanf left over
    getchar();

    fgets(input, sizeof(input), stdin);

    msgs[index] = input;
}
