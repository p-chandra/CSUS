// gcc example_3_integer_signs.c -o example_3_integer_signs -fno-stack-protector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFSIZE 100

int main(int argc, char **argv) {
    int inputSize;
    char inputBuf[BUFSIZE];
    char outputBuf[BUFSIZE];

    memset(inputBuf, 0, BUFSIZE);
    memset(outputBuf, 0, BUFSIZE);

    puts("Enter a string:");
    printf("> ");

    fgets(inputBuf, sizeof(inputBuf), stdin);

    puts("Copy how many bytes?");
    printf("> ");

    scanf("%d", &inputSize);

    if (inputSize < BUFSIZE) {
        memcpy(outputBuf, inputBuf, inputSize);
    }
    else {
        puts("Too many bytes!");
    }

    puts(outputBuf);
}
