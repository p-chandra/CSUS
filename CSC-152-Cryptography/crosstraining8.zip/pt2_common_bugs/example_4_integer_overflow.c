// gcc example_4_integer_overflow.c -o example_4_integer_overflow -fno-stack-protector
#include <stdio.h>
#include <string.h>

int main() {
    char inputBuf[100];
    char outputBuf[100];
    unsigned int copyLen;

    memset(inputBuf, 0, sizeof(inputBuf));
    memset(outputBuf, 0, sizeof(outputBuf));

    puts("Input a string:");
    printf("> ");

    fgets(inputBuf, sizeof(inputBuf), stdin);

    puts("Copy how many bytes?");
    printf("> ");

    scanf("%d", &copyLen);

    // We're going to add five "!" to the end of our string, so we need to make sure we have
    // enough room!
    if (copyLen + 5 < sizeof(outputBuf)) {
        memcpy(outputBuf, inputBuf, copyLen);

        for (int i = 0; i < 5; i++) {
            outputBuf[copyLen + i] = '!';
        }
    }

    puts(outputBuf);
}
