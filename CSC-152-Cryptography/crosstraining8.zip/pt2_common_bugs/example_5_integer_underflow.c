// gcc example_5_integer_underflow.c -o example_5_integer_underflow -fno-stack-protector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char inputBuf[100];
    char outputBuf[100];
    unsigned int strLen;

    memset(inputBuf, 0, sizeof(inputBuf));
    memset(outputBuf, 0, sizeof(outputBuf));

    puts("Input a string:");
    printf("> ");

    fgets(inputBuf, sizeof(inputBuf), stdin);

    strLen = strlen(inputBuf);    

    if (strLen < sizeof(inputBuf)) {
        memcpy(outputBuf, inputBuf + 5, strLen - 5);

        printf("%s\n", outputBuf);
    }
    else {
        puts("something went wrong");
        exit(-1);
    }
}
