// gcc practice_1.c -o practice_1 -fno-stack-protector
#include <stdio.h>
#include <string.h>

int main() {
    int i1;
    int i2;
    int i3;
    int i4;
    char inputBuf[10];

    i1 = 0;
    i2 = 0;
    i3 = 0;
    i4 = 0;
    memset(inputBuf, 0, sizeof(inputBuf));

    puts("Enter 4 numbers (Space separated)");
    printf("> ");

    scanf("%u %u %u %u", &i1, &i2, &i3, &i4);

    sprintf(inputBuf, "%d %d %d %d", i1, i2, i3, i4);

    puts(inputBuf);
}
