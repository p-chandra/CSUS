// gcc practice_2.c -o practice_2
#include <stdio.h>
#include <stdlib.h>

#define FUNCCOUNT 3

void print_emoji() {
    puts("┻━┻︵ \(°□°)/ ︵ ┻━┻");
}

void random_number() {
    printf("%d\n", rand());
}

void shutdown() {
    puts("[*] Goodbye");
    exit(0);
}

void (*menuFuncs[FUNCCOUNT])() = {
    print_emoji,
    random_number,
    shutdown
};

int main() {
    unsigned int input;

    puts("[*] Welcome");

    while (1) {
        puts("[*] Choose your option:");
        puts("\t[1] Print an emoji");
        puts("\t[2] Generate a random number");
        puts("\t[3] Shutdown");

        printf("> ");

        scanf("%d", &input);
        // Remove trailing newline
        getchar();

        if (input < FUNCCOUNT + 1) {
            menuFuncs[input - 1]();
        }
        else {
            puts("Bad index!");
        }
    }
}
