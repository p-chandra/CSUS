// gcc practice_3.c -o practice_3 -fno-stack-protector
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFSIZE 100

int main() {
    char inputBuf[BUFSIZE];
    char outputBuf[BUFSIZE];
    int copyLen;

    memset(inputBuf, 0, BUFSIZE);
    memset(outputBuf, 0, BUFSIZE);

    puts("Input a string:");
    printf("> ");

    fgets(inputBuf, BUFSIZE, stdin);

    puts("Copy how many bytes?");
    printf("> ");

    scanf("%d", &copyLen);

    if (copyLen <= 0) {
        puts("Bytes must be greater than 0!");
        exit(-1);
    }

    int fullLen = copyLen + 1;

    if (fullLen > BUFSIZE) {
        puts("Too many bytes!");
        exit(-1);
    }

    memcpy(outputBuf, inputBuf, copyLen);
    outputBuf[copyLen] = '\0';

    puts(outputBuf);
}
