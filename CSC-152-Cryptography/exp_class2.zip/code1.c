#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv) {
    char buf[20];
    int admin=0;

    printf("Enter password: ");
    fflush(stdout);
    read(0, &buf, 30);
    
    if (admin == 1337) {
        printf("Welcome to the mainframe!\n");
    } else {
        printf("ACCESS DENIED!\n");
    }
    return 0;
}
