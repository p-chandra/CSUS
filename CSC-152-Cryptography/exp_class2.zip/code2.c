// Compile with no stack canaries and executable stack
// System ASLR must be disabled separately; see disable_aslr.sh

// Compile with no protections
// gcc -fno-stack-protector -z execstack -no-pie -o exec_code1 code1.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void secretBackdoor(void) {
    system("/bin/sh");
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: ./%s <username>", argv[0]);
        return -1;
    }
    char uname[50];
    memset((char *)&uname, 0, sizeof(uname));
    strcpy(uname, argv[1]);
    printf("Hello, %s!\n", uname);
    return 0;
}

