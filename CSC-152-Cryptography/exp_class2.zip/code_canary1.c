// Example of GCC Stack Canaries - Try to exploit this!

// WITH canaries: gcc -z execstack -fstack_protector -no-pie -o exec_code3_canary code3.c
// WITHOUT canaries: gcc -fno-stack-protector -z execstack -no-pie -o exec_code3_nocanary code3.c

// copy cmdline arg to buf

#include <string.h>

int main(int argc, char **argv) {
    char buf[20];
    strcpy(buf, argv[1]);
    return 0;
}
