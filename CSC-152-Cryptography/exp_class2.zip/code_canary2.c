// gcc -fno-stack-protector -z execstack -z norelro -no-pie -o exec_code3_nocanary code3.c

// copy cmdline arg to buf
// Manually implemented (brute-forceable) stack canaries

#include <string.h>

const int canary0 = 0x28457289;

int main(int argc, char **argv) {
    int canary = canary0;
    char buf[20];
    strcpy(buf, argv[1]);
    if (canary != canary0) {
        printf("*** STACK SMASHING DETECTED ***\n");
        exit(-1);
    }
    return 0;
}
