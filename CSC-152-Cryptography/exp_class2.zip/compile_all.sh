#!/bin/bash

# Compile class files with appropriate protections based on their objectives
# See code2 for the compile items to disable all compile-time protections

# NOTE: You need to disable ASLR for your system separately

# Function local overflows
gcc -fno-stack-protector -o exec_code1 code1.c

# Baby stack overflow
gcc -z execstack -fno-stack-protector -o exec_code2 code2.c

# Standard stack overflow
gcc -z execstack -z norelro -no-pie -fno-stack-protector -o exec_code3 code3.c
