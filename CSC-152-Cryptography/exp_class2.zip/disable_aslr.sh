#!/bin/bash

# Disable or enable ASLR for this session

# It may be required to do this for your whole system depending on your setup
# If so, login to the root user and run:
# echo 0 > /proc/sys/kernel/randomize_va_space
# To disable, echo 1 or 2 back to this file

if [ "$1" == "enable" ]; then
    sudo sysctl kernel.randomize_va_space=1
elif [ "$1" == "disable" ]; then
    sudo sysctl kernel.randomize_va_space=0
else
    sudo sysctl kernel.randomize_va_space=0
fi
